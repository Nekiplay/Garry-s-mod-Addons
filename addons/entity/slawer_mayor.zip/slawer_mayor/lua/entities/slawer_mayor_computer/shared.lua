ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.RenderGroup = RENDERGROUP_BOTH

ENT.PrintName = "Computer"
ENT.Category = "Slawer | Mayor"

ENT.Spawnable = true