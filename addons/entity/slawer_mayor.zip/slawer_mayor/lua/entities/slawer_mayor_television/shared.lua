ENT.Type = "anim"
ENT.Base = "base_gmodentity"
-- ENT.RenderGroup = RENDERGROUP_BOTH

ENT.PrintName = "Television"
ENT.Category = "Slawer | Mayor"

ENT.Spawnable = true