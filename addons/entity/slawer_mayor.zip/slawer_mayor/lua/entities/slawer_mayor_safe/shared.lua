ENT.Type = "anim"
ENT.Base = "base_anim"
-- ENT.RenderGroup = RENDERGROUP_BOTH

ENT.PrintName = "Safe"
ENT.Category = "Slawer | Mayor"

ENT.Spawnable = true

ENT.AutomaticFrameAdvance = true