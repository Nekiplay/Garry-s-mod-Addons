ENT.Type = "anim"
ENT.Base = "keypad_pattern"
ENT.PrintName = "Pattern Keypad Wire"
ENT.Author = "Metamist"
ENT.Spawnable = false
ENT.AdminSpawnable = false
