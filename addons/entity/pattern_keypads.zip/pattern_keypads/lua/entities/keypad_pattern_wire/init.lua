AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

function ENT:Initialize()
    if not WireLib then self:Remove() end

    self.BaseClass.Initialize(self)

    self.Outputs = WireLib.CreateOutputs(self, { "Access Granted", "Access Denied" })
end

function ENT:Reset()
    self.BaseClass.Reset(self)

	WireLib.TriggerOutput(self, "Access Granted", self.keypadData.outputOff)
	WireLib.TriggerOutput(self, "Access Denied", self.keypadData.outputOff)
end

function ENT:DoSignal(granted, activated)
    local output = activated and self.keypadData.outputOn or self.keypadData.outputOff

    if granted then
        WireLib.TriggerOutput(self, "Access Granted", output)
    else
        WireLib.TriggerOutput(self, "Access Denied", output)
    end
end
