include("shared.lua")

local function createFont(name, size)
    surface.CreateFont(name, {
        font = "Roboto",
        antialias = true,
        size = size,
        weight = 500,
    })
end

createFont("PatternKeypadWindow", 72)

local matWhite = CreateMaterial( "PatternKeypadMaterial", "UnlitGeneric", {
    ["$basetexture"] = "white",
    ["$vertexcolor"] = 1,
} )

function ENT:Initialize()
    self:InitializeShared()

    local boxSize = self.boxMax - self.boxMin

    self.guiScale = 0.02
    self.guiWidth = boxSize.y / self.guiScale
    self.guiHeight = boxSize.z / self.guiScale

    self.guiPos = Vector(self.boxMax.x + 0.02, self.boxMin.y, self.boxMax.z)
    self.guiAng = Angle(0, 90, 90)

    self.guiWorldPos = Vector()
    self.guiWorldAng = Angle()

    self.colPrimary = Color(59, 73, 84)
    self.colSecondary = Color(211, 47, 47)
    self.colAccessGranted = Color(100, 255, 50)
    self.colAccessDenied = Color(255, 40, 20)

    self.circleRadiusHover = 24
    self.circleRadiusChecked = 32
    self.circleRadius = 16

    self:CreateGrid()
end

function ENT:UpdateColors()
    local colorArr = string.Explode("-", self:GetColors())
    self.colPrimary = ColorAlpha(PatternKeypad.parseColor(colorArr[1]), 255)
    self.colSecondary = ColorAlpha(PatternKeypad.parseColor(colorArr[2]), 255)
    self.colAccessGranted = ColorAlpha(PatternKeypad.parseColor(colorArr[3]), 255)
    self.colAccessDenied = ColorAlpha(PatternKeypad.parseColor(colorArr[4]), 255)
end

function ENT:CreateGrid()
    self.grid = {}
    self.path = {}

    local w, h = self.guiWidth, self.guiHeight
    local gridW, gridH = self:GetGridWidth(), self:GetGridHeight()

    local offsetX = w / (gridW + 1)
    local offsetY = w / (gridH + 1)
    local rad = 16

    for x = 1, gridW do
        for y = 1, gridH do
            local entry = self.grid[x + y * gridW]
            if not entry then
                entry = {
                    radius = 0,
                    color = Color(0, 0, 0, 80),
                    x = 0,
                    y = 0,
                }
                self.grid[x + y * gridW] = entry
            end

            entry.x = offsetX * x
            entry.y = h - offsetY * gridH + (y - 1) * offsetY
        end
    end
end

function ENT:GetCursorPosition()
    local rayVec = util.IntersectRayWithPlane(LocalPlayer():GetShootPos(), LocalPlayer():GetAimVector(), self.guiWorldPos, self.guiWorldAng:Up())
    if not rayVec then return 0, 0 end

    local dist = LocalPlayer():GetShootPos():Distance(rayVec)
    if dist > PatternKeypad.clickRange then return 0, 0 end

    local localRayVec = WorldToLocal(rayVec, Angle(), self.guiWorldPos, self.guiWorldAng)
    local boxSize = self.boxMax - self.boxMin

    local cursorFractX = localRayVec.x / boxSize.y
    local cursorFractY = -localRayVec.y / boxSize.z

    if cursorFractX < 0 or cursorFractX > 1 or cursorFractY < 0 or cursorFractY > 1 then
        return -1, -1
    end

    return cursorFractX * self.guiWidth, cursorFractY * self.guiHeight
end

function ENT:SendCombination(combination)
    net.Start("keypad_pattern_combination")
        net.WriteEntity(self)
        net.WriteInt(#combination, 8)
        for i = 1, #combination do
            net.WriteInt(combination[i], 8)
        end
    net.SendToServer()
end


function ENT:Think()
    local lp = LocalPlayer()

    if lp:KeyDown(IN_USE) and self:GetStatus() == self.STATUS_NONE then
        local cursorX, cursorY = self:GetCursorPosition()
        local gridW, gridH = self:GetGridWidth(), self:GetGridHeight()

        for cx = 1, gridW do
            for cy = 1, gridH do
                local entry = self.grid[cx + cy * gridW]

                if entry.hovered then
                    if not entry.checked then
                        surface.PlaySound(PatternKeypad.soundClick)

                        self.path[#self.path + 1] = {
                            id = cx + cy * gridW,
                            time = 0,
                        }
                    end

                    entry.checked = true
                end
            end
        end
    else
        if #self.path > 0 then
            local combination = {}

            for i = 1, #self.path do
                local dat = self.path[i]
                self.grid[dat.id].checked = false

                combination[#combination + 1] = dat.id
            end

            if #combination > 1 then
                self:SendCombination(combination)
            end

            self.path = {}
        end
    end


    local colorStr = self:GetColors()
    if colorStr ~= self.oldColorStr then
        self:UpdateColors()
    end
    self.oldColorStr = colorStr
end
local startTime = CurTime()
local startTime2 = CurTime()
function ENT:DrawOverlay()
    local elapsed = FrameTime()

    local w, h = self.guiWidth, self.guiHeight

    local cursorX, cursorY = self:GetCursorPosition()

    self.guiWorldPos = self:LocalToWorld(self.guiPos)
    self.guiWorldAng = self:LocalToWorldAngles(self.guiAng)
    cam.Start3D2D(self.guiWorldPos, self.guiWorldAng, self.guiScale)
        draw.NoTexture()

        surface.SetDrawColor(self.colPrimary)
        surface.DrawRect(0, 0, w, h)

        surface.SetDrawColor(Color(0, 0, 0, 80))
        surface.DrawRect(40, 40, w - 80, 150)

        if self:GetStatus() == self.STATUS_GRANTED then
            draw.DrawText(PatternKeypad.language.textGranted, "PatternKeypadWindow", w / 2, 40 + 75 - 36, self.colAccessGranted, TEXT_ALIGN_CENTER)
        elseif self:GetStatus() == self.STATUS_DENIED then
            draw.DrawText(PatternKeypad.language.textDenied, "PatternKeypadWindow", w / 2, 40 + 75 - 36, self.colAccessDenied, TEXT_ALIGN_CENTER)
        end

        for i = 1, #self.path - 1 do
            local dat = self.path[i]
            dat.time = dat.time + (1 - dat.time) * 12 * elapsed

            local entry = self.grid[dat.id]
            local nextEntry = self.grid[self.path[i + 1].id]

            local dx = nextEntry.x - entry.x
            local dy = nextEntry.y - entry.y
            local ang = math.deg(math.atan2(-dy, dx))

            local mx = (nextEntry.x + entry.x) / 2
            local my = (nextEntry.y + entry.y) / 2
            local dist = math.sqrt(dx * dx + dy * dy)
            surface.SetDrawColor(ColorAlpha(self.colSecondary, dat.time * 255))
            surface.DrawTexturedRectRotated(mx, my, dist, dat.time * 20, ang)
        end


        local gridW, gridH = self:GetGridWidth(), self:GetGridHeight()
        if #self.grid - gridW ~= gridW * gridH then
            self:CreateGrid()
        end

        for cx = 1, gridW do
            for cy = 1, gridH do
                local entry = self.grid[cx + cy * gridW]

                local dx = cursorX - entry.x
                local dy = cursorY - entry.y
                local dist = math.sqrt(dx * dx + dy * dy)

                local hovered = dist < self.circleRadiusChecked
                if not entry.checked and not entry.hovered and hovered then
                    surface.PlaySound(PatternKeypad.soundHover)
                end
                entry.hovered = hovered

                if entry.checked then
                    entry.radius = entry.radius + (self.circleRadiusChecked - entry.radius) * 12 * elapsed
                    entry.color = PatternKeypad.lerpColor(entry.color, self.colSecondary, 12 * elapsed)
                else
                    if hovered then
                        entry.radius = entry.radius + (self.circleRadiusHover - entry.radius) * 12 * elapsed
                    else
                        entry.radius = entry.radius + (self.circleRadius - entry.radius) * 8 * elapsed
                    end
                    entry.color = PatternKeypad.lerpColor(entry.color, Color(0, 0, 0, 80), 12 * elapsed)
                end

                PatternKeypad.drawCircle(entry.x, entry.y, entry.radius, 24, entry.color)
            end
        end

    cam.End3D2D()
end

function ENT:Draw()
    render.SuppressEngineLighting(true)
    render.SetMaterial(matWhite)
    render.DrawBox(self:GetPos(), self:GetAngles(), self.boxMin, self.boxMax, self.colPrimary, false)

    local lp = LocalPlayer()

    local dist = LocalPlayer():GetPos():Distance(self:GetPos())
    if dist > 150 then
        render.SuppressEngineLighting(false)
        surface.SetAlphaMultiplier(1)
        return
    end

    surface.SetAlphaMultiplier(1 - math.Clamp((dist - 125) / 25, 0, 1))

    local dot = (lp:GetShootPos() - self:GetPos()):Dot(self:GetForward())
    if dot > 0 then
        self:DrawOverlay()
    end
    render.SuppressEngineLighting(false)
    surface.SetAlphaMultiplier(1)
end





-- These functions are only here so no errors occur when used with willox's keypad,
-- because this addon aims to be compatible with the keypad cracker.
function ENT:GetHoveredElement()
end

function ENT:SendCommand()
end
