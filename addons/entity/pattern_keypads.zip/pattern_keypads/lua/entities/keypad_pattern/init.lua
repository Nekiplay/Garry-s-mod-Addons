AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

util.AddNetworkString("keypad_pattern_combination")

function ENT:Initialize()
    self:InitializeShared()

    self:SetModel(self.Model)

	self:PhysicsInit(SOLID_VPHYSICS)

	local phys = self:GetPhysicsObject()
	if IsValid(phys) then
		phys:Wake()
	end
end

AccessorFunc(ENT, "m_Combination", "Combination")
AccessorFunc(ENT, "keypadData", "Data")

function ENT:SetData(data)
    self.keypadData = data

    self:SetCombination(data.combination)
    self:SetGridWidth(data.width)
    self:SetGridHeight(data.height)
end

function ENT:Reset()
    self:SetStatus(self.STATUS_NONE)
end

function ENT:CheckCombination(tbl)
    local combo = self:GetCombination()

    if #tbl ~= #combo then return false end
    for i = 1, #tbl do
        if tbl[i] ~= combo[i] then return false end
    end

    return true
end

function ENT:ProcessCombination(tbl)
    self:Process(self:CheckCombination(tbl))
end

function ENT:Process(granted)
    if self:GetStatus() ~= self.STATUS_NONE then return end

    if granted then
        self:EmitSound(PatternKeypad.soundAccessGranted)
        self:SetStatus(self.STATUS_GRANTED)
    else
        self:EmitSound(PatternKeypad.soundAccessDenied)
        self:SetStatus(self.STATUS_DENIED)
    end
    local prefix = granted and "granted" or "denied"

    local length = self.keypadData[prefix .. "Length"]
    local repeats = self.keypadData[prefix .. "Repeats"]
    local delay = self.keypadData[prefix .. "Delay"]
    local initDelay = self.keypadData[prefix .. "InitDelay"]

    local owner = self.keypadData.owner

    timer.Simple(math.max(initDelay + length * (repeats + 1) + delay * repeats + 0.25, 2), function()
        if IsValid(self) then
            self:Reset()
        end
    end)

    timer.Simple(initDelay, function()
        if not IsValid(self) then return end

        for i = 0, repeats do
            timer.Simple((length + delay) * i, function()
                if IsValid(self) and IsValid(owner) then
                    self:DoSignal(granted, true)
                end
            end)

            timer.Simple(length * (i + 1) + delay * i, function()
                if IsValid(self) and IsValid(owner) then
                    self:DoSignal(granted, false)
                end
            end)
        end
    end)
end

function ENT:DoSignal(granted, activated)
    local key = granted and self.keypadData.grantedKey or self.keypadData.deniedKey
    local owner = self.keypadData.owner

    if activated then
        numpad.Activate(owner, key, true)
    else
        numpad.Deactivate(owner, key, true)
    end
end

local function checkDistance(ent, ply)
    if not IsValid(ent) or not IsValid(ply) then return false end

    local trace = ply:GetEyeTrace()
    if trace.Entity ~= ent then return false end
    if trace.HitPos:Distance(ply:GetShootPos()) > PatternKeypad.clickRange then return false end

    return true
end

net.Receive("keypad_pattern_combination", function(len, ply)
    local ent = net.ReadEntity()
    if not IsValid(ent) then return end
    if not IsValid(ply) then return end



    if not string.StartWith(ent:GetClass():lower(), "keypad_pattern") then return end
    if ent:GetStatus() ~= ent.STATUS_NONE then return end

    local combination = {}
    local count = net.ReadInt(8)
    for i = 1, count do
        combination[#combination + 1] = net.ReadInt(8)
    end

    ent:ProcessCombination(combination)
end)
