TEAM_ZTM_TRASHMAN = DarkRP.createJob("Уборщик мусора", {
    color = Color(20, 150, 20, 255),
      model = {
        "models/player/tfa_trent_cleaner_sniper.mdl"
    },
    description = [[Вы чистите город.]],
    weapons = {"ztm_trashcollector"},
    command = "zwf_trashman",
    max = 4,
    salary = 125,
    admin = 0,
    vote = false,
    category = "Гражданские",
    hasLicense = false,
})
