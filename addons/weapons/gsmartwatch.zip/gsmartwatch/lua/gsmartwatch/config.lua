GSmartWatch.Cfg = {}

GSmartWatch.Cfg.Language = "ru"                 -- Script language [en, fr, ge, po, sp]
GSmartWatch.Cfg.UseKey = KEY_G                  -- Default use key (full list here: https://wiki.facepunch.com/gmod/Enums/KEY)

GSmartWatch.Cfg.ViewModelLight = true           -- Set this to true if you want to apply light on the viewmodel
GSmartWatch.Cfg.ForceRealTime = true           -- Set this to true if you want to force real time usage (if StormFox is installed)

GSmartWatch.Cfg.CarFinderUpdateTime = 30        -- How many seconds before the car infos are updated (Car Finder app)
GSmartWatch.Cfg.CarKeyDistance = 1000           -- Max units between the player and the car to lock/unlock

GSmartWatch.Cfg.HideIncompatibilities = false   -- Set this to true to automatically disable apps that requires other script to be supported (will override GSmartWatch.Cfg.DisabledApps)
GSmartWatch.Cfg.DisabledApps = {                -- Set an app on true if you want to disable it
    [ "app_alarm" ] = false,
    [ "app_bank" ] = false,
    [ "app_carfinder" ] = false,
    [ "app_carkeys" ] = false,                  -- DarkRP needed - VCMod is only needed for lights (but is optionnal)
    [ "app_compass" ] = false,
    [ "app_fitness" ] = false,
    [ "app_health" ] = false,
    [ "app_services" ] = false,    
    [ "app_stockmarket" ] = false,              -- Required : Stock Market System
    [ "app_stopwatch" ] = false,
    [ "app_taxes" ] = false,                    -- Required : Slawer Mayor or DarkRP Mayor System
    [ "app_weather" ] = false,                  -- Required : StormFox
}

GSmartWatch.Cfg.BlacklistedTeams = {            -- List of teams to which you don't want to attach a smartwath (true to disable)
    [ "Hobo" ] = true,
}

GSmartWatch.Cfg.BlacklistedModels = {           -- List of playermodels to which you don't want to attach a smartwath (true to disable)
    [ "models/player/corpse1.mdl" ] = true,
    [ "models/zerochain/props_bloodlab/zbl_hazmat.mdl" ] = true,    
}

if SERVER then return end

-- Band colors
GSmartWatch.Cfg.Bands = {
    { name = "Black", color = Color( 32, 32, 32 ) },
    { name = "Grey", color = Color( 53, 59, 72 ) },
    { name = "White", color = Color( 240, 240, 240 ) },
    { name = "Pumpkin", color = Color( 211, 84, 0 ) },
    { name = "Orange", color = Color( 243, 156, 18 ) },
    { name = "Yellow", color = Color( 255, 255, 0 ) },
    { name = "Turquoise", color = Color( 26, 188, 156 ) },
    { name = "Blue", color = Color( 52, 152, 219 ) },
    { name = "Dark Blue", color = Color( 25, 42, 86 ) },
    { name = "Green", color = Color( 76, 209, 55 ) },
    { name = "Magenta", color = Color( 109, 33, 79 ) },
    { name = "Pink", color = Color( 252, 66, 123 ) },
    { name = "Red", color = Color(192, 57, 43 ) }
}

-- UI Colors
GSmartWatch.Cfg.Colors = {
    [ 0 ] = Color( 24, 25, 28 ),
    [ 1 ] = Color( 32, 34, 37 ),
    [ 2 ] = Color( 47, 49, 54 ),
    [ 3 ] = Color( 54, 57, 63 ),
    [ 4 ] = Color( 179, 183, 188 ),
    [ 5 ] = Color( 46, 204, 113 )
}