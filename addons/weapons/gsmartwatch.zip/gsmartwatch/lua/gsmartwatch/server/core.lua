util.AddNetworkString( "GSmartWatchNW" )
-- resource.AddWorkshop( "2101969034" ) WILL BE BACK ONCE IT'S FIXED 

--[[

    downloadFolderContent

]]--

local function downloadFolderContent( sPath )
	local tFiles, tFolders = file.Find( sPath .. "/*", "GAME" )

    for _, v in pairs( tFiles ) do
		resource.AddFile( sPath .. "/" .. v )
	end

	for _, v in pairs( tFolders ) do
		downloadFolderContent( sPath .. "/" .. v )
	end
end

downloadFolderContent( "materials/gsmartwatch" )
downloadFolderContent( "materials/sterling" )
downloadFolderContent( "models/sterling" )
downloadFolderContent( "sound/gsmartwatch" )

resource.AddFile( "resource/fonts/Rajdhani-Bold.ttf" )
resource.AddFile( "resource/fonts/Rajdhani-Regular.ttf" )

--[[

    requestWatchDeploy

]]--

local function requestWatchDeploy( pPlayer )
    if pPlayer:IsSmartWatchDisabled() then
        return
    end

    if not pPlayer:HasWeapon( "gsmartwatch" ) then
        pPlayer.GSW_LastSWEPGive = ( pPlayer.GSW_LastSWEPGive or 0 )
        if ( CurTime() < ( pPlayer.GSW_LastSWEPGive + .5 ) ) then
            return
        end

        -- Meh..
        if McPhone and pPlayer:GetNWBool( "McPhone.HasPhone" ) then
            pPlayer:SetNWBool( "McPhone.HasPhone", false )
            pPlayer.bShouldGiveMcPhone = true
        end

        pPlayer.GSW_LastSWEPGive = CurTime()
        pPlayer:Give( "gsmartwatch", true )

        local eWeapon = pPlayer:GetWeapon( "gsmartwatch" )
        pPlayer:SetActiveWeapon( eWeapon )
        eWeapon:Deploy()

        hook.Run( "GSmartWatch_OnDeploy", pPlayer, eWeapon )
    end
end

--[[

    requestWatchHolster

]]--

local function requestWatchHolster( pPlayer )
    if pPlayer:InVehicle() then
        return
    end

    if pPlayer:HasWeapon( "gsmartwatch" ) then
        if ( pPlayer:GetActiveWeapon():GetClass() == "gsmartwatch" ) then
            pPlayer:GetActiveWeapon():Holster()

            if pPlayer.bShouldGiveMcPhone then
                pPlayer:SetNWBool( "McPhone.HasPhone", true )
                pPlayer.bShouldGiveMcPhone = nil
            end
        end
    end
end

--[[

    lockUnlockVehicle

]]--

local function lockUnlockVehicle( pPlayer, i )
    if not DarkRP or not VC then
        return
    end

    local eVehicle = ( GSmartWatch.SpawnedVehicles and GSmartWatch.SpawnedVehicles[ pPlayer ] ) or false 
    if not eVehicle or not IsValid( eVehicle ) or not eVehicle:IsVehicle() then
        return
    end

    if ( pPlayer:GetPos():Distance( eVehicle:GetPos() ) < GSmartWatch.Cfg.CarKeyDistance ) then
        if ( i == 0 ) then
            if DarkRP then
                eVehicle:keysLock()
            else
                eVehicle:VC_lock()                    
            end
        else
            if DarkRP then
                eVehicle:keysUnLock()
            else
                eVehicle:VC_unLock()
            end
        end

        local iAlarmSound = CreateSound( eVehicle, "gsmartwatch/carlock.mp3" )
        iAlarmSound:SetSoundLevel( 90 )
        iAlarmSound:Play()

        if VC then
            if timer.Exists( "GSmartWatch_CarLighting_" .. pPlayer:SteamID() ) then
                timer.Destroy( "GSmartWatch_CarLighting_" .. pPlayer:SteamID() )
            end

            local bOn = false

            timer.Create( "GSmartWatch_CarLighting_" .. pPlayer:SteamID(), .1, 4, function()
                if not pPlayer or not IsValid( pPlayer ) then
                    return
                end

                if not eVehicle or not IsValid( eVehicle ) or not eVehicle:IsVehicle() then
                    return
                end

                bOn = not bOn

                eVehicle:VC_setHazardLights( bOn )
                eVehicle:VC_setRunningLights( bOn )
                eVehicle:VC_setFogLights( bOn )
                eVehicle:VC_setTurnLightLeft( bOn )
                eVehicle:VC_setTurnLightRight( bOn )
            end )
        end
    end
end

--[[

    GSmartWatchNW

]]--

local tPacket = {
    -- Deploy
    [ 0 ] = function( pPlayer )
        requestWatchDeploy( pPlayer )
    end,
    -- Holster
    [ 1 ] = function( pPlayer )
        requestWatchHolster( pPlayer )
    end,
    -- Car keys
    [ 2 ] = function( pPlayer )
        local i = net.ReadUInt( 2 )
        if not i or ( i > 1 ) or ( i < 0 ) then
            return
        end

        lockUnlockVehicle( pPlayer, i )
    end,
    -- Taxi
    [ 3 ] = function( pPlayer )
        if SlownLS and SlownLS.Taxi and SlownLS.Taxi.Call then
            SlownLS.Taxi:Call( pPlayer )
        end
    end
}

net.Receive( "GSmartWatchNW", function( iLen, pPlayer )
    pPlayer.GSW_LastPacketSent = ( pPlayer.GSW_LastPacketSent or 0 )
    if ( CurTime() < ( pPlayer.GSW_LastPacketSent + .2 ) ) then
        return
    end

    pPlayer.GSW_LastPacketSent = CurTime()

    local iMsg = net.ReadUInt( 2 )
    if not iMsg or not tPacket[ iMsg ] then
        return
    end

    tPacket[ iMsg ]( pPlayer )    
end )