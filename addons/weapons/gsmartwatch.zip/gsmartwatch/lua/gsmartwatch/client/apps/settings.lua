local GSWApp = {}

GSWApp.ID = "app_settings"
GSWApp.Name = GSmartWatch.Lang.Apps[ "Settings" ]
GSWApp.Icon = Material( "materials/gsmartwatch/apps/settings.png", "smooth" )

local tCacheCfg = {}

--[[

    GSWApp:RunApp

]]--

local tSettingsButtons = {}
local iSelected = false
local xSubMenu = false

function GSWApp.Run( dBase )
    if not dBase or not IsValid( dBase ) then
        return
    end

    tSettingsButtons = {}
    iSelected = false
    xSubMenu = false

    if not dBase or not IsValid( dBase ) then
        return
    end

    dBase.RunningApp = vgui.Create( "DPanel", dBase )
    dBase.RunningApp:SetSize( dBase:GetWide(), dBase:GetTall() )
    dBase.RunningApp.Paint = nil

    dBase.RunningApp.dScroll = vgui.Create( "DScrollPanel", dBase.RunningApp )
    dBase.RunningApp.dScroll:SetSize( ( dBase:GetWide() * .64 ), ( dBase:GetTall() * .68 ) )
    dBase.RunningApp.dScroll:SetPos( ( dBase:GetWide() * .18 ), ( dBase:GetTall() * .16 ) )

    local dBar = dBase.RunningApp.dScroll:GetVBar()
    dBar:SetWidth( 0 )
    dBar:SetVisible( false )

    local iID = -1

    for k, v in SortedPairs( GSmartWatch.ClientSettings ) do
        iID = ( iID + 1 )

        iSelected = ( iSelected or iID )

        local dButton = dBase.RunningApp.dScroll:Add( "DButton" )
        dButton:SetSize( dBase.RunningApp.dScroll:GetWide(), ( dBase.RunningApp.dScroll:GetTall() * .2 ) )
	    dButton:SetText( GSmartWatch.Lang.Settings[ k ] or k )
        dButton:SetFont( "GSmartWatch.32" )
        dButton:SetTextColor( color_white )
        dButton:SetContentAlignment( 5 )
        dButton:Dock( TOP )
	    dButton:DockMargin( 0, 0, 0, 26 )
        dButton.sKey = k
        dButton.iIndex = iID

        tSettingsButtons[ iID ] = dButton

        function dButton:Paint( iW, iH )
            local bHovered = ( self.iIndex == iSelected )

            self:SetFont( bHovered and "GSmartWatch.48" or "GSmartWatch.32" )
            self:SetTextColor( ( self.iIndex == iSelected ) and color_white or GSmartWatch.Cfg.Colors[ 3 ] )
        end
    end
end

--[[

    GSWApp.OnUse

]]--

function GSWApp.OnUse( dBase, sBind )
    if not dBase or not IsValid( dBase ) then
        return
    end

    local dPanel = dBase.RunningApp

    if ( sBind == "invnext" ) then
        if not xSubMenu and ( iSelected and dPanel.dScroll ) then
            iSelected = ( tSettingsButtons[ iSelected + 1 ] and ( iSelected + 1 ) or 0 )
            dPanel.dScroll:ScrollToChild( tSettingsButtons[ iSelected ] )

            return
        end

        -- Sub menus
        if ( xSubMenu.ID == "BandColor" ) then
            xSubMenu:SelectNeighbour( true )

        elseif ( xSubMenu.ID == "UIVolume" ) then
            xSubMenu:SetValue( xSubMenu.iValue - 10 )
        end

    elseif ( sBind == "invprev" ) then
        if not xSubMenu and ( iSelected and dPanel.dScroll ) then
            iSelected = ( tSettingsButtons[ iSelected - 1 ] and ( iSelected - 1 ) or #tSettingsButtons )
            dPanel.dScroll:ScrollToChild( tSettingsButtons[ iSelected ] )

            return
        end

        -- Sub menus
        if ( xSubMenu.ID == "BandColor" ) then
            xSubMenu:SelectNeighbour()

        elseif ( xSubMenu.ID == "UIVolume" ) then
            xSubMenu:SetValue( xSubMenu.iValue + 10 )
        end

    elseif ( sBind == "+attack" ) then
        if xSubMenu and xSubMenu.ID then
            if ( xSubMenu.ID == "BandColor" ) then
                if xSubMenu.tCachedColor and IsColor( xSubMenu.tCachedColor ) then
                    GSmartWatch:SaveClientSetting( "BandColor", xSubMenu.tCachedColor )
                    LocalPlayer():GetActiveWeapon():SetBandColor( xSubMenu.tCachedColor )

                    GSmartWatch:Notify( GSmartWatch.Lang[ "Updated watchband" ], 2 )
                end

            elseif ( xSubMenu.ID == "IsToggle" ) then
                xSubMenu:InvertToggle()
                GSmartWatch:SaveClientSetting( "IsToggle", xSubMenu.bToggled )
                GSmartWatch:Notify( ( xSubMenu.bToggled and GSmartWatch.Lang[ "Key : Toggle" ] or GSmartWatch.Lang[ "Key : Hold" ] ), 2 )

            elseif ( xSubMenu.ID == "Is24hCycle" ) then
                xSubMenu:InvertToggle()
                GSmartWatch:SaveClientSetting( "Is24hCycle", xSubMenu.bToggled )
                GSmartWatch:Notify( ( xSubMenu.bToggled and GSmartWatch.Lang[ "24h clock" ] or GSmartWatch.Lang[ "12h clock" ] ), 2 )

            elseif ( xSubMenu.ID == "UIVolume" ) then
                GSmartWatch:SaveClientSetting( "UIVolume", ( xSubMenu.iValue * .01 ) )
                GSmartWatch:Notify( "Volume set to " .. xSubMenu.iValue, 2 )
            end

            return
        end

        local sKey = tSettingsButtons[ iSelected ].sKey

        if ( sKey == "BandColor" ) then
            dPanel:Clear()
            xSubMenu = GSmartWatch:DrawColorScroller( "BandColor", dPanel, GSmartWatch.Cfg.Bands, 0 )

        elseif ( sKey == "Is24hCycle" ) then
            dPanel:Clear()
            xSubMenu = GSmartWatch:DrawCheckBox( "Is24hCycle", dPanel, GSmartWatch.ClientSettings[ "Is24hCycle" ], GSmartWatch.Lang[ "Time system" ] )

        elseif ( sKey == "IsToggle" ) then
            dPanel:Clear()
            xSubMenu = GSmartWatch:DrawCheckBox( "IsToggle", dPanel, GSmartWatch.ClientSettings[ "IsToggle" ], GSmartWatch.Lang[ "Set key toggle" ] )

        elseif ( sKey == "UIVolume" ) then
            dPanel:Clear()
            xSubMenu = GSmartWatch:DrawNumWang( "UIVolume", dPanel, ( GSmartWatch.ClientSettings[ "UIVolume" ] * 100 ), 0, 100, GSmartWatch.Lang[ "Adjust UI volume" ] )

        elseif ( sKey == "WatchFace" ) then
            GSmartWatch:RunApp( "app_watchfaces" )
        end

    elseif ( sBind == "+attack2" ) then
    end
end

GSmartWatch:RegisterApp( GSWApp )
GSWApp = nil