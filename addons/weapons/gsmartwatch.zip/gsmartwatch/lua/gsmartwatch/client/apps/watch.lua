local GSWApp = {}

GSWApp.ID = "app_watch"
GSWApp.Name = GSmartWatch.Lang.Apps[ "Watch" ]
GSWApp.IsInvisible = true

--[[

    GSWApp:RunApp

]]--

function GSWApp.Run( dBase )
    if not dBase or not IsValid( dBase ) then
        return
    end

    dBase.RunningApp = vgui.Create( "DPanel", dBase )
    dBase.RunningApp:SetSize( dBase:GetWide(), dBase:GetTall() )

    GSmartWatch.WatchFaces[ ( GSmartWatch.ClientSettings.WatchFace or 1 ) ].func( dBase )
end

--[[

    GSWApp.OnUse

]]--

function GSWApp.OnUse( dBase, sBind )
    GSmartWatch.LastUse = ( GSmartWatch.LastUse or 0 )
    if ( CurTime() < ( GSmartWatch.LastUse - .5 ) ) then
        return
    end

    if ( sBind == "+attack" ) then
        GSmartWatch:RunApp( "app_myapps" )
    end

    GSmartWatch.LastUse = CurTime() + .2
end

GSmartWatch:RegisterApp( GSWApp )
GSWApp = nil