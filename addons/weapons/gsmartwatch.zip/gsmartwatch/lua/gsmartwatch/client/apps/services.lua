if GSmartWatch.Cfg.DisabledApps[ "app_services" ] then
    return
end

local GSWApp = {}

GSWApp.ID = "app_services"
GSWApp.Name = GSmartWatch.Lang.Apps[ "Services" ]
GSWApp.Icon = Material( "materials/gsmartwatch/apps/services.png", "smooth" )
GSWApp.ShowTime = true

--[[

    GSWApp:RunApp

]]--

function GSWApp.Run( dBase )
    if not dBase or not IsValid( dBase ) then
        return
    end

    local tServices = {}

    dBase.RunningApp = vgui.Create( "DPanel", dBase )
    dBase.RunningApp:SetSize( dBase:GetWide(), dBase:GetTall() )

    function dBase.RunningApp:Paint( iW, iH )
        GSmartWatch:SetStencil()

        draw.SimpleText( GSmartWatch.Lang[ "Press to call" ], "GSmartWatch.32", ( iW * .5 ), ( iH * .7 ), color_white, 1, 1 )

        render.SetStencilEnable( false )
    end

    if VS_PoliceMod and VS_PoliceMod.DisplayHelpCallMenu then
        table.insert( tServices, {
            name = GSmartWatch.Lang[ "Police" ],
            icon = Material( "materials/gsmartwatch/police_car.png", "smooth" ),
            func = function()
                VS_PoliceMod:DisplayHelpCallMenu()
            end
        })
    end

    if SlownLS and SlownLS.Taxi then
        table.insert( tServices, {
            name = GSmartWatch.Lang[ "Taxi" ],
            icon = Material( "materials/gsmartwatch/taxi.png", "smooth" ),
            func = function()
                net.Start( "GSmartWatchNW" )
                    net.WriteUInt( 3, 2 )
                net.SendToServer()
            end
        })
    end

    if MSystem and MSystem.NetStart then
        table.insert( tServices, {
            name = GSmartWatch.Lang[ "Mechanic" ],
            icon = Material( "materials/gsmartwatch/tow_truck.png", "smooth" ),
            func = function()
                MSystem:NetStart( "SendRequest" )
            end
        })
    end

        -- table.insert( tServices, {
        --     name = GSmartWatch.Lang[ "Ambulance" ],
        --     icon = Material( "materials/gsmartwatch/ambulance.png", "smooth" ),
        --     func = function()
        --     end
        -- })

    if ( CONFIG_SERVICES and CONFIG_SERVICES.Settings ) then
        for k, v in pairs( CONFIG_SERVICES.Settings ) do
            table.insert( tServices, {
                name = k .. ( v.price and ( v.price > 0 ) and " | " .. GSmartWatch:FormatMoney( v.price ) or "" ),
                icon = Material( "materials/" .. v.icon, "smooth" ),
                func = function()
                    ServicesCall( k , v.icon, LocalPlayer():GetPos() )
                end
            } )
        end
    end

    if ( #tServices == 0 ) then
        return GSmartWatch:PaintError( dBase.RunningApp, GSmartWatch.Lang[ "No service found" ] )
    end

    dBase.RunningApp.dCurService = vgui.Create( "DPanel", dBase.RunningApp )
    dBase.RunningApp.dCurService:SetSize( ( dBase:GetWide() * .4 ), ( dBase:GetTall() * .4 ) )
    dBase.RunningApp.dCurService:SetPos( ( dBase:GetWide() * .3 ), ( dBase:GetTall() * .2 ) )

    dBase.RunningApp.dCurService.tServices = tServices
    dBase.RunningApp.dCurService.fLerp = 0

    function dBase.RunningApp.dCurService:SetService( iIndex )
        if not tServices[ iIndex ] then
            return false
        end

        self.name = tServices[ iIndex ].name or false
        self.icon = tServices[ iIndex ].icon or false
        self.func = tServices[ iIndex ].func or false

        self.iSelected = iIndex
    end

    dBase.RunningApp.dCurService:SetService( 1 )

    function dBase.RunningApp.dCurService:Paint( iW, iH )
        self.fLerp = Lerp( RealFrameTime() * 10, self.fLerp, ( iH * .6 ) )

        if self.icon then
            surface.SetDrawColor( color_white )
            surface.SetMaterial( self.icon )
            surface.DrawTexturedRectRotated( ( iW * .5 ), ( iH * .5 ), self.fLerp, ( iH * .6 ), 0 )
        end

        draw.SimpleText( ( self.name or "" ), "GSmartWatch.48", ( iW * .5 ), ( iH * 1.05 ), color_white, 1, 1 )
    end
end

--[[

    GSWApp.OnUse

]]--

function GSWApp.OnUse( dBase, sBind )
    if not dBase or not IsValid( dBase ) then
        return
    end

    if ( sBind == "invnext" ) then
        if ( dBase.RunningApp and dBase.RunningApp.dCurService ) then
            local dPanel = dBase.RunningApp.dCurService
            if not dPanel.tServices or ( #dPanel.tServices < 1 ) then
                return
            end

            local iSelected = ( dPanel.iSelected + 1 )
            if ( iSelected > #dPanel.tServices ) then
                iSelected = 1
            end

            dPanel:SetService( iSelected )
            dPanel.fLerp = 0
        end

    elseif ( sBind == "invprev" ) then
        if ( dBase.RunningApp and dBase.RunningApp.dCurService ) then
            local dPanel = dBase.RunningApp.dCurService
            if not dPanel.tServices or ( #dPanel.tServices < 1 ) then
                return
            end

            local iSelected = ( dPanel.iSelected - 1 )
            if ( iSelected < 1 ) then
                iSelected = #dPanel.tServices
            end
            
            dPanel:SetService( iSelected )
            dPanel.fLerp = 0
        end

    elseif ( sBind == "+attack" ) then
        if ( dBase.RunningApp and dBase.RunningApp.dCurService ) then
            local dPanel = dBase.RunningApp.dCurService
            if not dPanel.tServices or ( #dPanel.tServices < 1 ) then
                return
            end

            if dPanel.func then
                dPanel.func()
            end
        end
    end
end

GSmartWatch:RegisterApp( GSWApp )
GSWApp = nil