local GSW_W, GSW_H = 454, 454
local matLoading = Material( "materials/gsmartwatch/loading.png", "smooth" )

--[[

	getSmartWatchBorders

]]--

local function getSmartWatchBorders( x, y, radius, seg )
	local tPoly = {}

	table.insert( tPoly, { x = x, y = y, u = 0.5, v = 0.5 } )
	for i = 0, seg do
		local a = math.rad( ( i / seg ) * -360 )
		table.insert( tPoly, { x = x + math.sin( a ) * radius, y = y + math.cos( a ) * radius, u = math.sin( a ) / 2 + 0.5, v = math.cos( a ) / 2 + 0.5 } )
	end

	local a = math.rad( 0 )
	table.insert( tPoly, { x = x + math.sin( a ) * radius, y = y + math.cos( a ) * radius, u = math.sin( a ) / 2 + 0.5, v = math.cos( a ) / 2 + 0.5 } )

    return tPoly
end

local tBorders = getSmartWatchBorders( ( GSW_W * .5 ), ( GSW_H * .5 ), ( GSW_H * .5 ), 12 )

function GSmartWatch:SetStencil()
	render.SetStencilWriteMask( 0xFF )
	render.SetStencilTestMask( 0xFF )
	render.SetStencilReferenceValue( 0 )
	render.SetStencilPassOperation( STENCIL_KEEP )
	render.SetStencilZFailOperation( STENCIL_KEEP )
	render.ClearStencil()

	render.SetStencilEnable( true )
	render.SetStencilReferenceValue( 1 )
	render.SetStencilCompareFunction( STENCIL_NEVER )
	render.SetStencilFailOperation( STENCIL_REPLACE )

    surface.SetDrawColor( color_black )
	draw.NoTexture()
    surface.DrawPoly( tBorders )

	render.SetStencilCompareFunction( STENCIL_EQUAL )
	render.SetStencilFailOperation( STENCIL_KEEP )
end

--[[

    GSmartWatch:DrawScreen

]]--

function GSmartWatch:DrawScreen( eSWEP )
    eSWEP.BaseUI = vgui.Create( "DPanel" )
    eSWEP.BaseUI:SetSize( GSW_W, GSW_H )
    eSWEP.BaseUI:SetPaintedManually( true )
	eSWEP.BaseUI:SetAlpha( 0 )
	eSWEP.BaseUI:AlphaTo( 255, .5, 0 )

	GSmartWatch:Play2DSound( "gsmartwatch/ui/unlock.mp3" )

	function eSWEP.BaseUI:OnRemove()
		GSmartWatch:Play2DSound( "gsmartwatch/ui/lock.mp3" )
	end

	eSWEP.BaseUI.Paint = nil
	GSmartWatch:RunApp( GSmartWatch.CurrentApp or "app_watch" )
end

--[[

	GSmartWatch:Notify()

]]--

function GSmartWatch:Notify( sNotifText, iDuration )
	if not LocalPlayer():IsUsingSmartWatch() then
		return 
	end

	local eWeapon = LocalPlayer():GetActiveWeapon()
	if not eWeapon.BaseUI or not IsValid( eWeapon.BaseUI ) then
		return
	end

	if eWeapon.BaseUI.NotifPanel then
		eWeapon.BaseUI.NotifPanel:Remove()
		timer.Remove( "GSmartWatch_NotifTimer" )
	end

	local iDuration = ( iDuration or 1.5 )

	eWeapon.BaseUI.NotifPanel = vgui.Create( "DLabel", eWeapon.BaseUI )
	local dNotif = eWeapon.BaseUI.NotifPanel

	dNotif:SetFont( "GSmartWatch.32" )
	dNotif:SetText( sNotifText )
	dNotif:SetContentAlignment( 5 )
	dNotif:SetWide( eWeapon.BaseUI:GetWide() * .84 )
	dNotif:SetTextInset( 10, 0 )
	dNotif:SetWrap( true )
	dNotif:SizeToContents()
	dNotif:SetZPos( 100 )
	dNotif:SetAlpha( 0 )
	dNotif:AlphaTo( 255, .5, 0 )
	dNotif:SetPos( ( eWeapon.BaseUI:GetWide() * .5 ) - ( dNotif:GetWide() * .5 ), eWeapon.BaseUI:GetTall() - dNotif:GetTall() )
	dNotif:MoveTo( ( eWeapon.BaseUI:GetWide() * .5 ) - ( dNotif:GetWide() * .5 ), ( eWeapon.BaseUI:GetTall() * .7 ) - dNotif:GetTall(), .5, 0, .5 )

	local iLoaded = 0
	local iDelay = .05
    local lastOccurance = CurTime()			

	function dNotif:Paint( iW, iH )
    	local timeElapsed = ( CurTime() - lastOccurance )

        if ( timeElapsed > iDelay ) then
        	iLoaded = ( iLoaded + iDelay )
            lastOccurance = CurTime()
        end

		local iWidth = ( iLoaded * ( iW + ( iH * .1 ) ) / iDuration  )
		iWidth = ( ( iWidth > iW ) and iW or iWidth )

		DisableClipping( true )
			draw.RoundedBox( 0, -( iH * .06 ), -( iH * .06 ), ( iW + ( iH * .1 ) ), ( iH + ( iH * .12 ) ), ColorAlpha( color_white, 10 ) )
			draw.RoundedBox( 0, -( iH * .06 ), iH, iWidth, ( iH * .06 ), GSmartWatch.Cfg.Colors[ 5 ] )
		DisableClipping( false )		
	end

	timer.Create( "GSmartWatch_NotifTimer", iDuration, 1, function()
		if eWeapon and IsValid( eWeapon ) and eWeapon.BaseUI and eWeapon.BaseUI.NotifPanel and IsValid( eWeapon.BaseUI.NotifPanel ) then
			eWeapon.BaseUI.NotifPanel:AlphaTo( 0, .25, 0 )
			eWeapon.BaseUI.NotifPanel:MoveTo( ( eWeapon.BaseUI:GetWide() * .5 ) - ( dNotif:GetWide() * .5 ), eWeapon.BaseUI:GetTall() - dNotif:GetTall(), .25, 0, .5, function()
				if eWeapon.BaseUI.NotifPanel and IsValid( eWeapon.BaseUI.NotifPanel ) then
					eWeapon.BaseUI.NotifPanel:Remove()
					eWeapon.BaseUI.NotifPanel = nil
				end
			end )
		end		
	end )

	GSmartWatch:Play2DSound( "gsmartwatch/ui/notify.mp3" )
end

--[[

	GSmartWatch:PaintError

]]--

function GSmartWatch:PaintError( dPanel, sErrorMessage )
	if not dPanel or not IsValid( dPanel ) then
		return
	end

    function dPanel:Paint( iW, iH )
		surface.SetDrawColor( GSmartWatch.Cfg.Colors[ 0 ] )
		surface.SetMaterial( matLoading )
		surface.DrawTexturedRectRotated( ( iW * .5 ), ( iH * .5 ), ( iH * .4 ), ( iH * .4 ), ( CurTime() * 180 ) )
        draw.SimpleText( sErrorMessage, "GSmartWatch.48", ( iW * .5 ), ( iH * .5 ), color_white, 1, 1 )
	end
end

--[[

	GSmartWatch:DrawColorScroller

]]--

function GSmartWatch:DrawColorScroller( sID, dBase, tColors, iValue )
    if not dBase or not IsValid( dBase ) then
        return
    end

    local iSelected = ( iValue or 0 )

    local dPanel = vgui.Create( "DPanel", dBase )
    dPanel:SetSize( dBase:GetWide(), dBase:GetTall() )
	dPanel.Paint = nil
	dPanel.ID = ( sID or nil )
	dPanel.tButtons = {}
	dPanel.tCachedColor = false

	function dPanel:SelectNeighbour( bNext )
        iSelected = bNext and ( iSelected + 1 ) or ( iSelected - 1 )

		if not self.tButtons[ iSelected ] then
            iSelected = bNext and 0 or #self.tButtons
        end

        self.dScroll:ScrollToChild( self.tButtons[ iSelected ] )

        if self.tButtons[ iSelected ].tBtnColor then
            self.tCachedColor = self.tButtons[ iSelected ].tBtnColor
        end
	end

    dPanel.dScroll = vgui.Create( "DScrollPanel", dPanel )
    dPanel.dScroll:SetSize( ( dBase:GetWide() * .64 ), ( dBase:GetTall() * .65 ) )
    dPanel.dScroll:SetPos( ( dBase:GetWide() * .18 ), ( dBase:GetTall() * .175 ) )

    local dBar = dPanel.dScroll:GetVBar()
    dBar:SetWidth( 0 )
    dBar:SetVisible( false )

    local iID = -1
    for k, v in SortedPairs( tColors ) do
        iID = ( iID + 1 )

        iSelected = ( iSelected or iID )

        local dButton = dPanel.dScroll:Add( "DButton" )
        dButton:SetSize( dPanel.dScroll:GetWide(), ( dPanel.dScroll:GetTall() * .16 ) )
        dButton:SetText( v.name )
        dButton:SetFont( "GSmartWatch.32" )
        dButton:SetTextColor( color_white )
        dButton:SetContentAlignment( 4 )
        dButton:SetTextInset( ( dButton:GetTall() * 1.2 ), 0 )
        dButton:Dock( TOP )
	    dButton:DockMargin( 0, 0, 0, 26 )
        dButton.sKey = k
        dButton.iIndex = iID
        dButton.tBtnColor = v.color

        dPanel.tButtons[ iID ] = dButton

        function dButton:Paint( iW, iH )
			local bSelected = ( self.iIndex == iSelected )
			local iOffset = bSelected and ( iH * .2 ) or 0

            if bSelected then
                draw.RoundedBox( ( iH * .2 ), iOffset, 0, iH, iH, color_white )
            end

			self:SetTextInset( ( dButton:GetTall() * 1.2 ) + ( iOffset * 1.5 ), 0 )

            draw.RoundedBox( ( iH * .2 ) - 3, 3 + iOffset, 3, iH - 6, iH - 6, ColorAlpha( v.color, bSelected and 255 or 60 ) )

			
            self:SetTextColor( bSelected and color_white or GSmartWatch.Cfg.Colors[ 3 ] )
        end
    end

    return dPanel
end

--[[

	GSmartWatch:DrawCheckBox

]]--

function GSmartWatch:DrawCheckBox( sID, dBase, bDefault, sTitle )
    if not dBase or not IsValid( dBase ) then
        return
    end

    local dPanel = vgui.Create( "DPanel", dBase )
    dPanel:SetSize( dBase:GetWide(), dBase:GetTall() )
	dPanel.Paint = nil
	dPanel.ID = ( sID or nil )
	dPanel.bToggled = ( bDefault or false )

	function dPanel:InvertToggle()
		self.bToggled = not self.bToggled
		self.dCheck:SetValue( self.bToggled )
	end

	if sTitle then
		local dTitle = vgui.Create( "DLabel", dPanel )
		dTitle:SetSize( dBase:GetWide(), dBase:GetTall() * .15 )
		dTitle:SetPos( 0, dBase:GetTall() * .3 )
		dTitle:SetText( sTitle )
		dTitle:SetFont( "GSmartWatch.48" )
		dTitle:SetContentAlignment( 5 )
	end

	dPanel.dCheck = vgui.Create( "DCheckBox", dPanel )
	dPanel.dCheck:SetSize( ( dPanel:GetWide() * .24 ), ( dPanel:GetTall() * .08 ) )
	dPanel.dCheck:SetPos( ( dPanel:GetWide() * .5 ) - ( dPanel.dCheck:GetWide() * .5 ), ( dPanel:GetTall() * .5 ) )
	dPanel.dCheck:SetValue( dPanel.bToggled )

	local fLerpX = ( dPanel.dCheck:GetChecked() and ( dPanel.dCheck:GetWide() - dPanel.dCheck:GetTall() ) or 0 )

	function dPanel.dCheck:Paint( iW, iH )
		fLerpX = Lerp( RealFrameTime() * 10, fLerpX, ( self:GetChecked() and ( iW - iH ) or 0 ) )

		draw.RoundedBox( ( iH * .5 ) + 5, - 5, - 5, iW + 10, iH + 10, GSmartWatch.Cfg.Colors[ 0 ] )
		draw.RoundedBox( ( iH * .5 ), fLerpX, 0, iH, iH, self:GetChecked() and GSmartWatch.Cfg.Colors[ 5 ] or GSmartWatch.Cfg.Colors[ 2 ] )
	end

	return dPanel
end

--[[

	GSmartWatch:DrawNumWang

]]--

function GSmartWatch:DrawNumWang( sID, dBase, iDefault, iMin, iMax, sTitle )
    if not dBase or not IsValid( dBase ) then
        return
    end

    local dPanel = vgui.Create( "DPanel", dBase )
    dPanel:SetSize( dBase:GetWide(), dBase:GetTall() )
	dPanel.Paint = nil
	dPanel.ID = ( sID or nil )
	dPanel.iValue = ( iDefault or false )

	function dPanel:SetValue( iValue )
		self.dNum:SetValue( iValue )
		self.iValue = self.dNum:GetValue()
	end

	if sTitle then
		local dTitle = vgui.Create( "DLabel", dPanel )
		dTitle:SetSize( dBase:GetWide(), dBase:GetTall() * .15 )
		dTitle:SetPos( 0, dBase:GetTall() * .3 )
		dTitle:SetText( sTitle )
		dTitle:SetFont( "GSmartWatch.48" )
		dTitle:SetContentAlignment( 5 )
	end

	dPanel.dNum = vgui.Create( "DNumberWang", dPanel )
	dPanel.dNum:SetSize( ( dPanel:GetWide() * .5 ), ( dPanel:GetTall() * .06 ) )
	dPanel.dNum:SetPos( ( dPanel:GetWide() * .5 ) - ( dPanel.dNum:GetWide() * .5 ), ( dPanel:GetTall() * .5 ) )
	dPanel.dNum:SetMinMax( ( iMin or 0 ), ( iMax or 0 ) )
	dPanel.dNum:SetValue( dPanel.iValue )
	dPanel.dNum:HideWang()

	local fLerp = dPanel.iValue

	function dPanel.dNum:Paint( iW, iH )
		fLerp = Lerp( RealFrameTime() * 6, fLerp, self:GetValue() )

		local iX = ( fLerp * iW / 100 )
		local iX2 = ( fLerp * ( iW - iH ) / 100 )

		draw.RoundedBox( ( iH * .25 ), 0, 0, iW, ( iH * .5 ), GSmartWatch.Cfg.Colors[ 0 ] )
		draw.RoundedBox( ( iH * .25 ), 0, 0, iX, ( iH * .5 ), GSmartWatch.Cfg.Colors[ 5 ] )
		
		draw.RoundedBox( ( iH * .5 ), iX2, - ( iH * .25 ), iH, iH, color_white )
		draw.SimpleText( math.Round( fLerp ), "GSmartWatch.48", ( iW * .5 ), ( iH * 2 ), GSmartWatch.Cfg.Colors[ 2 ], 1, 1 )
	end

	return dPanel
end

--[[

	GSmartWatch:DrawBinder

]]--

function GSmartWatch:DrawBinder( sID, dBase, iDefault, sTitle )
    if not dBase or not IsValid( dBase ) then
        return
    end

    local dPanel = vgui.Create( "DPanel", dBase )
    dPanel:SetSize( dBase:GetWide(), dBase:GetTall() )
	dPanel.Paint = nil
	dPanel.ID = ( sID or nil )

	function dPanel:SetKey( iKey )
		self.dBinder:SetSelectedNumber( iKey )
		self.iKey = self.dBinder:GetValue()
	end

	timer.Simple( .1, function()
		if dPanel and IsValid( dPanel ) then
			hook.Remove( "PlayerButtonDown", "GSmartWatch_KeyBinding" )
			hook.Add( "PlayerButtonDown", "GSmartWatch_KeyBinding", function( pPlayer, iKey )
				if ( pPlayer == LocalPlayer() ) and dPanel and IsValid( dPanel ) then
					dPanel:SetKey( iKey )
				end
			end )
		end
	end )

	function dPanel:OnRemove()
		hook.Remove( "PlayerButtonDown", "GSmartWatch_KeyBinding" )
	end

	if sTitle then
		local dTitle = vgui.Create( "DLabel", dPanel )
		dTitle:SetSize( dBase:GetWide(), dBase:GetTall() * .2 )
		dTitle:SetPos( 0, dBase:GetTall() * .25 )
		dTitle:SetText( sTitle )
		dTitle:SetFont( "GSmartWatch.48" )
		dTitle:SetContentAlignment( 5 )
	end

	dPanel.dBinder = vgui.Create( "DBinder", dPanel )
	dPanel.dBinder:SetSize( ( dPanel:GetWide() * .5 ), ( dPanel:GetTall() * .06 ) )
	dPanel.dBinder:SetPos( ( dPanel:GetWide() * .5 ) - ( dPanel.dBinder:GetWide() * .5 ), ( dPanel:GetTall() * .65 ) )
	dPanel.dBinder:SetTextColor( color_black )

	function dPanel.dBinder:Paint( iW, iH )
		draw.SimpleText( string.upper( input.GetKeyName( self:GetValue() ) ), "GSmartWatch.64", ( iW * .5 ), ( iH * .5 ), color_white, 1, 1 )
	end

	dPanel:SetKey( iDefault or GSmartWatch.Cfg.DefaultKey )

	return dPanel
end